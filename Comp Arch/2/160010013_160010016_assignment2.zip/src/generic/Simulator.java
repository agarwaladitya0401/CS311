package generic;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.*;
import java.io.*;
import java.io.FileOutputStream;
import java.io.DataOutputStream;

import generic.Operand.OperandType;
import generic.ParsedProgram;
import generic.Instruction;


public class Simulator {
		
	static FileInputStream inputcodeStream = null;
	public static String addr;
	public static int fcaddr;
	public enum r3 {add, sub, mul, div, and, or, xor,
					slt, sll, srl, sra};
	public enum r2i {addi, subi, muli, divi, andi, ori,
					 xori, slti, slli, srli, srai, load,
					 store, beq, bne, blt, bgt};
	public enum ri {jmp, end};
	
	public static HashMap<String, String> map =
			new HashMap<String, String>();
	
	public static void setupSimulation(
			String assemblyProgramFile,
			String objectProgramFile)
	{	
		addr = objectProgramFile;
		int firstCodeAddress = ParsedProgram.parseDataSection(
				assemblyProgramFile);
		fcaddr = firstCodeAddress;
		ParsedProgram.parseCodeSection(
				assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
		map.put("add",   "00000");
		map.put("addi",  "00001");
		map.put("sub",   "00010");
		map.put("subi",  "00011");
		map.put("mul",   "00100");
		map.put("muli",  "00101");
		map.put("div",   "00110");
		map.put("divi",  "00111");
		map.put("and",   "01000");
		map.put("andi",  "01001");
		map.put("or",    "01010");
		map.put("ori",   "01011");
		map.put("xor",   "01100");
		map.put("xori",  "01101");
		map.put("slt",   "01110");
		map.put("slti",  "01111");
		map.put("sll",   "10000");
		map.put("slli",  "10001");
		map.put("srl",   "10010");
		map.put("srli",  "10011");
		map.put("sra",   "10100");
		map.put("srai",  "10101");
		map.put("load",  "10110");
		map.put("jmp",   "11000");
		map.put("beq",   "11001");
		map.put("bne",   "11010");
		map.put("blt",   "11011");
		map.put("bgt",   "11100");
		map.put("end",   "11101");
		map.put("store", "10111");
	}
	
	public static String get_bin_str(int value, int x)
	{
		String str = Integer.toBinaryString(value);
//		System.out.println("+++++++++++++++++ "+str);
		System.out.println("Value: "+value);
		if(value<0)
		{
			System.out.println("HEllo");
			String new_str="";
			for(int k = str.length()-1;k>=str.length()-x;k--)
			{
				new_str = str.charAt(k) + new_str;
			}
			System.out.println("new_str: "+new_str+ "  " + new_str.length());
			System.out.println("============================================");
			str=new_str;
		}
		int len = str.length();
		String zeros = "";
		if(len < 5)
		{
			int len_to_produce = x - len;
			for(int j = 0; j<len_to_produce;j++)
			{
				zeros += "0";
			}
		}
		str = zeros + str;
		return(str);
	}
	
	public static String get_bin_str_1(int value, int x)
	{
		String str = Integer.toBinaryString(value);
		int len = str.length();
		String zeros = "";
		if(len < 5)
		{
			int len_to_produce = x - len;
			for(int j = 0; j<len_to_produce;j++)
			{
				zeros += "0";
			}
		}
		str = str+zeros;
		return(str);
	}
	
	public static String get_op_src_1_str(Instruction inst)
	{
		Operand op = inst.getSourceOperand1();
		return(get_bin_str(op.getValue(),5));
	}
	
	public static String get_op_src_2_str(Instruction inst)
	{
		Operand op = inst.getSourceOperand2();
		return(get_bin_str(op.getValue(),5));
	}
	
	public static void write_to_file(List<String> inst_list)
	{
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try
		{
			fos = new FileOutputStream(addr);
			dos = new DataOutputStream(fos);
			dos.writeInt(fcaddr);
			for(int k=0;k<ParsedProgram.data.size();k++)
			{
				int x = ParsedProgram.data.get(k);
				System.out.println("data x: "+x);
				dos.writeInt(x);
				System.out.println("Writing data");
			}
			for(int k=0;k<inst_list.size();k++)
			{
				String x = inst_list.get(k);
				System.out.println("inst x: "+x);
				int bits = (int) Long.parseLong(x, 2);
				System.out.println("bits: "+bits+"\t"+Integer.toHexString(bits));
				dos.writeInt(bits);
				System.out.println("Writing instructions");
			}
			
			
		}
		catch(IOException e)
		{
			
		}
		finally
		{
			try {
			if(fos!=null)
				fos.close();
			if(dos!=null)
				dos.close();
			}
			catch(IOException ex)
			{}
		}
	}
	
	public static void assemble()
	{
		//TODO your assembler code
		int main_fun_addr = ParsedProgram.mainFunctionAddress;
		List<String> inst_list = new ArrayList<String>();
		int count_inst_list = 0;
		try
		{
			for(int i=main_fun_addr;;i++)
			{
				String instruction = "";
				Instruction current_inst = 
						ParsedProgram.getInstructionAt(i);
				Instruction.OperationType inst_name = 
						current_inst.getOperationType();
				r3 op3;
				r2i op2i;
				ri opi;
				String opcode = map.get(inst_name.toString());
				instruction+=opcode;
				Operand rd;
				String rs1, rs2, im;
				rd = current_inst.getDestinationOperand();
				String rd_str="";
				if(!(rd==null))
				{
					int rd_value=-1;
					if(inst_name.toString().equals("bgt")||inst_name.toString().equals("blt")||
					   inst_name.toString().equals("beq")||inst_name.toString().equals("bne"))
					{
						System.out.println("PC: "+current_inst.getProgramCounter());
						System.out.println("imm: "+(ParsedProgram.symtab.get(rd.getLabelValue())
						                          -current_inst.getProgramCounter()));
						rd_str = get_bin_str(ParsedProgram.symtab.get(rd.getLabelValue())-current_inst.getProgramCounter(), 17);
						System.out.println("rd_Str: "+rd_str+"  "+ ParsedProgram.symtab.get(rd.getLabelValue()));
					}
					else
					{
						rd_value = rd.getValue();
						rd_str = get_bin_str(rd_value,5);
					}
				}
				
				//----------------------------------------------------------
				count_inst_list++;
				try
				{
					op3 = r3.valueOf(inst_name.toString()); 
					// Instruction is of type r3
					rs1 = get_op_src_1_str(current_inst);
					rs2 = get_op_src_2_str(current_inst);
					String zero_string="";
					for(int k=0;k<12;k++)
						zero_string+="0";
					instruction = instruction + rs1 + rs2 + rd_str + zero_string;
				}
				catch(IllegalArgumentException ex)
				{
					// Instruction is not of type r3
				}
				
				
				
				
				//----------------------------------------------------------
				try
				{
					op2i = r2i.valueOf(inst_name.toString()); 
					// Instruction is of type r2i
					if(inst_name.toString().equals("bgt")||inst_name.toString().equals("blt")||
					   inst_name.toString().equals("beq")||inst_name.toString().equals("bne"))
					{
						System.out.println(current_inst.getSourceOperand1().getOperandType());
						System.out.println(current_inst.getSourceOperand2().getOperandType());
						System.out.println(current_inst.getDestinationOperand().getOperandType());
						rs2 = get_op_src_2_str(current_inst);
						rs1 = get_op_src_1_str(current_inst);
						instruction = instruction + rs1+ rs2 + rd_str;
						int bits = (int) Long.parseLong(instruction, 2);
						System.out.println("INSTRUCTION: "+Integer.toHexString(bits));
					}
					else
					{
						rs1 = get_op_src_1_str(current_inst);
						int im_value;
						if(inst_name.toString().equals("load")||inst_name.toString().equals("store"))
						{
							im = current_inst.getSourceOperand2().getLabelValue();
							im_value = ParsedProgram.symtab.get(im);
						}
						else
						{
							im_value = current_inst.getSourceOperand2().getValue();
						}
	//					int im_value = ParsedProgram.symtab.get(im);
						String im_str = get_bin_str(im_value, 17);
						instruction = instruction + rs1 + rd_str + im_str;
					}
				}
				catch(IllegalArgumentException ex)
				{
					// Instruction is not of type r2i
				}
				
				
				
				
				//----------------------------------------------------------
				try
				{
					opi = ri.valueOf(inst_name.toString());
					// Instruction is of type ri
					if(!(inst_name.toString().equals("end")))
					{
						im = current_inst.getSourceOperand2().getLabelValue();
						int im_value = ParsedProgram.symtab.get(im);
						String im_str = get_bin_str(im_value, 22);
						instruction = instruction + rd + im_str;
					}
					else
					{
						String zeros = "";
						for(int k=0;k<27;k++)
							zeros+="0";
						instruction = instruction + zeros;
					}
				}
				catch(IllegalArgumentException ex)
				{
					// Instruction is not of type ri
				}
				inst_list.add(instruction);
			}
			
		}
		catch(Exception e)
		{
			// Catches the ArrayList index out of bound error
		}
		System.out.println(inst_list);
		write_to_file(inst_list);
	}
	
}
