public class ENEMY
{
	int[] firstrow(int a[][])
	// Function which determines whether the enemy has moved or not on to the first row and
	// also the final coordinates after his first move.
	{
		int length_axis_val_for_first_row=0;
		int position_after_reaching_first_row[]=new int[2]; // First element determines whether the enemy moved
															// or not while the second position determines the coordinate
															// on the length axis, the final width axis coordinate known
															// to being one.
		int moved=0; // 1 when the new position for the enemy is found out, 0 otherwise
		for(int i=0; i<1000; i++)
		{
			if(a[0][i]==0)
			{
				length_axis_val_for_first_row=i;
				moved=1;
				break;
			}
		}
		position_after_reaching_first_row[0]=moved;
		position_after_reaching_first_row[1]=length_axis_val_for_first_row;
		return position_after_reaching_first_row;
	}

	int[] middlerow(int a[][],int width_axis_position,int length_axis_position)
	// Function which determines whether the enemy has moved or not whenever in between the first row and the last row
	// also the final coordinates after his first move.
	{ 
		int return_val[]=new int[3]; // Array of size 3 where 1st value determines whether the enemy has moved or not
									 // while the second and third position determine the coordinates on the grid. 
		int final_width_axis_pos=0;
		int final_length_axis_pos=0;
		int moved=0; // 1 when the new position for the enemy is found out, 0 otherwise
		
		// Assumed the enemy has 3 positions to move, forward, diagonally left or diagonally right.
		int diagonally_left_pos = a[0][0];
		if (length_axis_position !=0)
		{
			diagonally_left_pos=a[width_axis_position+1][length_axis_position-1];
		}
		int forward_pos=a[width_axis_position+1][length_axis_position];
		int diagonally_right_pos=a[width_axis_position+1][length_axis_position+1];
					
		// The enemy can move in all directions if it is in the middle of the grid.
		if(length_axis_position>0 && length_axis_position<999)
		{
			// The diagonally left cell if found to be off.
			if(diagonally_left_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position-1;
			}
			// The forward cell is found to be off.
			if(forward_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position;		
			}
			// The diagonally right cell is found to be off.
			if(diagonally_right_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position+1;
			}
		}
		// The enemy can move only forward or right if he/she is on the left border of the grid.
		if(length_axis_position==0)
		{
			// The forward cell is found to be off.
			if(forward_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position;		
			}
			// The diagonally right cell is found to be off.
			if(diagonally_right_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position+1;
			}
		}
		// The enemy can move only forward or left if he/she is on the right border of the grid.
		if(length_axis_position==999)
		{
			// The diagonally left cell is found to be off.
			if(diagonally_left_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position-1;
			}
			// The forward cell is found to be off.
			if(forward_pos==0 && a[width_axis_position][length_axis_position]==0)
			{
				moved=1;
				final_width_axis_pos=width_axis_position+1;
				final_length_axis_pos=length_axis_position;		
			}
		}

		// Preparing return value
		return_val[0]=moved;
		return_val[1]=final_width_axis_pos;
		return_val[2]=final_length_axis_pos;
		return return_val;	
	}

	int lastrow(int a[][],int width_axis_pos,int length_axis_pos)
	// Function which determines whether the enemy has moved on to the last row or not.
	{
		int moved=0; // 1 if enemy has moved to the last row, 0 otherwise.
		if(a[width_axis_pos][length_axis_pos]==0)
		{
			moved=1;
		}
		return moved;
	}
}
