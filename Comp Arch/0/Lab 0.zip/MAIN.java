import java.io.*;
public class MAIN
{
	 public static void main(String args[]) throws IOException
	 {
		 BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		 
		 // INPUTS
		 int width;
		 double probability;
		 System.out.println("ENTER THE PROBABILITY");
		 probability=Double.parseDouble(br.readLine());
		 System.out.println("ENTER THE WIDTH");
		 width=Integer.parseInt(br.readLine());
		 
		 // DECLARATIONS
		 SENSOR sensor = new SENSOR();
		 ENEMY enemy = new ENEMY();
		 int time=0;
		 int ret_val_first_row[] = new int[2]; // The first element tells us whether the enemy moved or not
		 									   // while the second value tells us its position on the length axis.
		 int width_axis_val;
		 
		 // Computation for the enemy moving on to the first row
		 while(true)
		 {
			 ret_val_first_row=enemy.firstrow(sensor.enemy(width,probability));
			 time=time+10;
			 if (ret_val_first_row[0]==1)
			 {
				 width_axis_val=ret_val_first_row[1];
				 break;
			 }
			
		 }
		 
		 // Computation for the enemy moving in between the first row and prior to moving to the last row.
		 int length_axis_val=0;
		 for(int i=1; i<width-1; i++)
		 {
			 int ret_val_middle_row[] = new int[3]; // The first element tells us whether the enemy moved or not
			   										// while the second and third values tells us the coordinates
			 										// of the grid.
			 while(true)
			 {
				 ret_val_middle_row=enemy.middlerow(sensor.enemy(width,probability),length_axis_val,width_axis_val);
				 time=time+10;
				 if(ret_val_middle_row[0]==1)
				 {
					length_axis_val=ret_val_middle_row[1];
					width_axis_val=ret_val_middle_row[2];
					break;
				 }
			 }
		 }
		 
		 // Computation for the enemy moving on to the last row.
		 int ret_val_last_row; // Tells us whether the enemy moved on to the last row or not.
		 while(true)
		 {
			 ret_val_last_row=enemy.lastrow(sensor.enemy(width, probability), length_axis_val, width_axis_val);
		     time=time+10;
		     if(ret_val_last_row==1)
		     {
		    	 System.out.println(time);
		    	 break;
		     }
			 
		 }
	 }
}

	 
