public class SENSOR 
{
	public int[][] enemy(int width, double probability)
	{
		int a[][] = new int[width][1000];
		{
			for(int i = 0; i<width; i++)
			{
				for(int j=0; j<1000; j++)
				{
					double x = Math.random();
					if(x<probability)
					{
						a[i][j] = 1;
					}
					else 
					{
						a[i][j] = 0;
					}	
				}
			}
		}
		return a;
	}
}