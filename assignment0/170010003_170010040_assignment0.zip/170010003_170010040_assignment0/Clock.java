// Defines the Clock
public class Clock {
	int moves = 0;
}
